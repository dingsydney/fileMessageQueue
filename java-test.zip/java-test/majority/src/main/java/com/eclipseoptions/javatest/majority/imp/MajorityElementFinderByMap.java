package com.eclipseoptions.javatest.majority.imp;

import com.eclipseoptions.javatest.majority.api.MajorityElementFinder;

import java.util.*;

/**
 * Created by jding on 20/12/2017.
 */
public class MajorityElementFinderByMap implements MajorityElementFinder {
  /**
   * find the element that appears more than n/2 times.
   * @param numbers the array of elements from which to find the majority element.
   * @return
   */
  public int majorityElement(int[] numbers) {
    if(numbers==null || numbers.length==0) throw new IllegalArgumentException("Empty elements is now allowed");
    int threshold = numbers.length/2;
    Map<Integer,int[]> frequency = new HashMap<Integer, int[]>();
    for(int value:numbers){
      boolean isOverHalf = increaseFrequency(value,frequency,threshold);
      if(isOverHalf) return value;
    }
    throw new IllegalArgumentException("There is no majority number");
  }

  private boolean increaseFrequency(int value, Map<Integer, int[]> frequency, int threshold) {
    int[] freq = frequency.get(value);
    if(freq==null){
      freq = new int[1];
      frequency.put(value,freq);
    }
    freq[0]++;
    return freq[0]>threshold;
  }
}
