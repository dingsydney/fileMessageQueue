package com.eclipseoptions.javatest.majority.imp;

import com.eclipseoptions.javatest.majority.api.MajorityElementFinder;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.*;
import java.util.function.Function;
import java.util.stream.*;

/**
 * Created by jding on 20/12/2017.
 */
public class MajorityElementFinderByStream implements MajorityElementFinder {
  /**
   * find the element that appears more than n/2 times.
   * @param numbers the array of elements from which to find the majority element.
   * @return
   */

  public int majorityElement(int[] numbers) {
    if(numbers==null || numbers.length==0) throw new IllegalArgumentException("Empty elements is now allowed");
    int halfSize = numbers.length/2;
    Map<Integer,AtomicInteger> frequencyMap  = new ConcurrentHashMap<>(halfSize);
    Arrays.stream(numbers).distinct().parallel().forEach(value -> frequencyMap.put(value,new AtomicInteger(0)));
    AtomicBoolean notFound = new AtomicBoolean(true);
    Integer[] majorityNum = new Integer[1];
    Arrays.stream(numbers).parallel().forEach(value -> {
      if(notFound.get() && frequencyMap.get(value).incrementAndGet()>halfSize){
        notFound.compareAndSet(true,false);
        majorityNum[0] = value;
      }
    }
    );
    if (majorityNum[0] == null) throw new IllegalArgumentException("There is no majority number");
    return majorityNum[0];
  }

}
