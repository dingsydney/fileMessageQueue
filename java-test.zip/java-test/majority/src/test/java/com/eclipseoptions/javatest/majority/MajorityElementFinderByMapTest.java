package com.eclipseoptions.javatest.majority;

import com.eclipseoptions.javatest.majority.imp.MajorityElementFinderByMap;
import org.junit.Before;

/**
 * Created by jding on 21/12/2017.
 */
public class MajorityElementFinderByMapTest extends MajorityElementFinderTestBase {

  @Before
  public void setUp(){
    finder = new MajorityElementFinderByMap();
  }

}
