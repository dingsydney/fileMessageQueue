package com.eclipseoptions.javatest.majority;

import com.eclipseoptions.javatest.majority.imp.*;
import org.junit.Before;

/**
 * Created by jding on 21/12/2017.
 */
public class MajorityElementFinderByStreamTest extends MajorityElementFinderTestBase{
  @Before
  public void setUp(){
    finder = new MajorityElementFinderByStream();
  }

}
