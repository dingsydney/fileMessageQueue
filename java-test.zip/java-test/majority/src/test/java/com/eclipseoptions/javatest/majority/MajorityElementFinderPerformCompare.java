package com.eclipseoptions.javatest.majority;

import com.eclipseoptions.javatest.majority.api.MajorityElementFinder;
import com.eclipseoptions.javatest.majority.imp.*;
import org.junit.*;
import org.junit.rules.TestName;

import java.text.*;

import static org.junit.Assert.assertEquals;

/**
 * Created by jding on 21/12/2017.
 * Please specify VM parameters: -Xms=128m
 */
public class MajorityElementFinderPerformCompare {
  @Rule public TestName name = new TestName();

  private MajorityElementFinder[] finders = new MajorityElementFinder[2];
  int[] testData;
  int expectedMajorityNum;
  @Before
  public void setup(){
    finders[0] = new MajorityElementFinderByMap();
    finders[1] = new MajorityElementFinderByStream();
  }

  private void mockData_withAllNumbers() {
    int size = Integer.MAX_VALUE/800;
    if(size%2==0) size++;
    testData = new int[size];
    expectedMajorityNum = size + 100;
    int i=0;
    for(;i<size/2;i++){
      testData[2*i] = i;
      testData[2*i+1] = expectedMajorityNum;
    }
    testData[2*i] = expectedMajorityNum;
  }

  private void mockData_withFewNumbers() {
    int size = Integer.MAX_VALUE/100;
    if(size%2==0) size++;
    testData = new int[size];
    expectedMajorityNum = size + 100;
    int noiseNumber = 1;
    int i=0;
    for(;i<size/2;i++){
      testData[2*i] = noiseNumber;
      testData[2*i+1] = expectedMajorityNum;
    }
    testData[2*i] = expectedMajorityNum;
  }

  @Test
  public void performanceCompare_withManyDistNumber(){
    System.out.println("test case: "+name.getMethodName());
    mockData_withAllNumbers();
    for(MajorityElementFinder finder: finders) {
      long timeStart = System.nanoTime();
      int majority = finder.majorityElement(testData);
      assertEquals(expectedMajorityNum, majority);
      long timeEnd = System.nanoTime();
      System.out.println(String.format(finder.getClass().getName() + "'s cost to find the majority number:%,d", timeEnd - timeStart));
    }
  }

  @Test
  public void performanceCompare_withFewDistNumber(){
    System.out.println("test case: "+name.getMethodName());
    mockData_withFewNumbers();
    for(MajorityElementFinder finder: finders) {
      long timeStart = System.nanoTime();
      int majority = finder.majorityElement(testData);
      assertEquals(expectedMajorityNum, majority);
      long timeEnd = System.nanoTime();
      System.out.println(String.format(finder.getClass().getName() + "'s cost to find the majority number:%,d", timeEnd - timeStart));
    }
  }
}
