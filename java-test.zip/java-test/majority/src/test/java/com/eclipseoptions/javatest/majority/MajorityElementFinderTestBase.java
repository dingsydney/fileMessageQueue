package com.eclipseoptions.javatest.majority;

import com.eclipseoptions.javatest.majority.api.MajorityElementFinder;
import org.junit.*;

import static org.junit.Assert.*;

/**
 * Created by jding on 20/12/2017.
 */
public abstract class MajorityElementFinderTestBase {

  MajorityElementFinder finder;

  @Test(expected = IllegalArgumentException.class)
  public void nullElementTest(){
    assertEquals(1,finder.majorityElement(null));
  }

  @Test(expected = IllegalArgumentException.class)
  public void emptyElementTest(){
    assertEquals(1,finder.majorityElement(new int[0]));
  }

  @Test
  public void oneElementTest(){
    int[] data = {1};
    assertEquals(1,finder.majorityElement(data));
  }

  @Test
  public void twoElementsPositiveTest(){
    int[] data = {1,1};
    assertEquals(1,finder.majorityElement(data));
  }

  @Test(expected = IllegalArgumentException.class)
  public void twoElementsNegativeTest(){
    int[] data = {1,2};
    assertEquals(1,finder.majorityElement(data));
  }

  @Test
  public void manyEvenNumberedElementTest(){
    int[] data = {1,1,2,3,4,5,6,1,1,1,1,1};
    assertEquals(1,finder.majorityElement(data));
  }

  @Test
  public void manyOddNumberedElementTest(){
    int[] data = {1,1,2,3,4,5,6,1,1,1,1};
    assertEquals(1,finder.majorityElement(data));
  }

  @Test
  public void manyEvenNumberedElement_majorityInFront_Test(){
    int[] data = {1,1,1,1,1,1,1,2,3,4,5,6};
    assertEquals(1,finder.majorityElement(data));
  }

  @Test
  public void manyEvenNumberedElement_majoritySpreadOut_Test(){
    int[] data = {1,2,1,3,1,4,1,5,1,6,1,1};
    assertEquals(1,finder.majorityElement(data));
  }

  @Test
  public void majorityCompeteTest(){
    int[] data = {1,2,1,2,1,2,1,2,1,2,1};
    assertEquals(1,finder.majorityElement(data));
  }

}
