package com.eclipseoptions.javatest.imp;

import com.eclipseoptions.javatest.tuple.api.Tuple;

import java.util.*;

/**
 * Created by jding on 20/12/2017.
 */
public class ArrayTuple<T> implements Tuple<T> {

  private final T[] underlyingData;
  private final int size;

  public ArrayTuple(T... data) {
    if(data==null) throw new NullPointerException("Null is not allowed");
    size = data.length;
    underlyingData = (T[])new Object[size];
    System.arraycopy(data,0,underlyingData,0,size);
  }

  public ArrayTuple(Collection<T> data) {
    if(data==null) throw new NullPointerException("Null is not allowed");
    size = data.size();
    underlyingData = (T[])new Object[size];
    data.toArray(underlyingData);
  }

  /**
   * Gets the element at the given index in the tuple
   *
   * @param index the index of the element to be returned
   * @return the element at the given index in the tuple
   * @throws IndexOutOfBoundsException if the element is negative or greater than the last element index
   */
  public T get(int index) {
    checkBounds(index);
    return underlyingData[index];
  }

  /**
   * @param index the index of the element to be replace
   * @param value the value with which to replace the given element
   * @return
   */
  public Tuple<T> replace(int index, T value) {
    checkBounds(index);
    T[] newData = (T[])new Object[size];
    System.arraycopy(underlyingData,0,newData,0,size);
    newData[index] = value;
    return new ArrayTuple<T>(newData);
  }

  /**
   * Returns the number of elements in this tuple
   * @return the number of elements in this tuple
   */
  public int size() {
    return size;
  }

  /**
   * Returns an array containing the elements of this tuple in order
   * @return an array containing the elements of this tuple in order
   */
  public Object[] toArray() {
    Object[] target = new Object[size];
    System.arraycopy(underlyingData,0,target,0,size);
    return target;
  }

  /**
   * Returns an iterator over the elements of this tuple in order.
   * It is thread safe since the tuple is immutable.
   * @return an iterator over the elements of this tuple in order
   */
  public Iterator<T> iterator() {
    return new Iterator<T>() {
      private int position = 0;

      public boolean hasNext() {
        return position<size;
      }

      public T next() {
        if(position>=size) throw new NoSuchElementException();
        return underlyingData[position++];
      }

      /**
       * not support for immutable object
       */
      public void remove() {
        throw new UnsupportedOperationException("remove");
      }
    };
  }

  private void checkBounds(int index) throws IndexOutOfBoundsException{
    if(index<0 || index>=size) throw new IndexOutOfBoundsException();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    ArrayTuple<?> that = (ArrayTuple<?>) o;
    return Arrays.equals(underlyingData, that.underlyingData);
  }

  @Override
  public int hashCode() {
    int result = Arrays.hashCode(underlyingData);
    result = 31 * result + size;
    return result;
  }
}
