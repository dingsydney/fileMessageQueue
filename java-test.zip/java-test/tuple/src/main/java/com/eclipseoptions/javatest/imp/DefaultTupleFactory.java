package com.eclipseoptions.javatest.imp;

import com.eclipseoptions.javatest.tuple.api.*;

import java.util.Collection;

/**
 * Created by jding on 20/12/2017.
 */
public class DefaultTupleFactory implements TupleFactory {
  public <T> Tuple<T> newTuple(T[] arr) {
    return new ArrayTuple<T>(arr);
  }

  public <T> Tuple<T> newTuple(Collection<T> collection) {
    return new ArrayTuple<>(collection);
  }
}
