package com.eclipseoptions.javatest;

import com.eclipseoptions.javatest.imp.DefaultTupleFactory;
import com.eclipseoptions.javatest.tuple.api.*;
import org.junit.*;

import java.util.*;

import static org.junit.Assert.assertEquals;

/**
 * Created by jding on 22/12/2017.
 */
public class TupleFactoryTest {

  private TupleFactory factory;
  @Before
  public void setup(){
    factory = new DefaultTupleFactory();
  }
  @Test
  public void factoryTest(){
    String[] arr = new String[]{"a","b","c","d"};
    Collection<String> collecion = Arrays.asList(arr);
    Tuple arrayT = factory.newTuple(arr);
    Tuple collectionT = factory.newTuple(collecion);
    int size = arrayT.size();
    assertEquals(size,collectionT.size());
    for(int i=0;i<size;i++){
      assertEquals(arrayT.get(i),collectionT.get(i));
    }
  }
}
