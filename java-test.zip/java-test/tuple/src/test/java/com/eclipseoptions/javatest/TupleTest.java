package com.eclipseoptions.javatest;

import com.eclipseoptions.javatest.imp.*;
import com.eclipseoptions.javatest.tuple.api.*;
import org.junit.*;

import java.util.*;
import java.util.concurrent.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

/**
 * Created by jding on 22/12/2017.
 */
public class TupleTest {

  private Tuple<String> defaultTuple;
  String[] arr;
  TupleFactory factory;
  @Before
  public void setup(){
    factory = new DefaultTupleFactory();
    arr = new String[]{"a","b","c","d"};
    defaultTuple = factory.newTuple(arr);
  }

  @Test(expected = NullPointerException.class)
  public void testConstructorWithNullParam(){
    defaultTuple = new ArrayTuple<>((String[])null);
  }

  @Test(expected = IndexOutOfBoundsException.class)
  public void getTestWithNegativeIndex(){
    defaultTuple.get(-1);
  }

  @Test(expected = IndexOutOfBoundsException.class)
  public void getTestWithExceedIndex(){
    defaultTuple.get(arr.length);
  }

  @Test
  public void getAndSizeTest(){
    int size = arr.length;
    assertEquals(size, defaultTuple.size());
    for(int i=0;i<size;i++){
      assertEquals(arr[i], defaultTuple.get(i));
    }
  }

  @Test
  public void toArrayTest(){
    Object[] fromTuple = defaultTuple.toArray();
    //validate the value of elements
    for(int i=0;i<arr.length;i++){
      assertEquals(arr[i],fromTuple[i]);
    }
    //validate the immunity of the defaultTuple
    fromTuple[0] = "z";
    immunityTest();
  }

  @Test
  public void iteratorOnEmptyCollectionTest(){
    Iterator<String> iterator = factory.newTuple(new String[0]).iterator();
    assertFalse(iterator.hasNext());
  }

  @Test
  public void iteratorTest(){
    Iterator<String> iterator = defaultTuple.iterator();
    int index = 0;
    //validate the value of elements
    while(iterator.hasNext()){
      assertEquals(arr[index++],iterator.next());
    }
    //validate the size of elements
    assertEquals(arr.length,index);
    immunityTest();
  }

  @Test(expected = NoSuchElementException.class)
  public void iteratorExceedNextInvocationTest(){
    Iterator<String> iterator = defaultTuple.iterator();
    for(int i=0;i<=arr.length;i++){
      iterator.next();
    }
  }

  @Test
  public void iteratorThreadSafeTest(){
    int threadNum = 8;
    ExecutorService executor = Executors.newFixedThreadPool(threadNum);
    int numberOfIte = threadNum*4;
    Runnable[] iteRunnables = new Runnable[numberOfIte];
    for(int i=0;i<numberOfIte;i++) iteRunnables[i] = new Runnable() {
      @Override
      public void run() {
        Iterator<String> ite = defaultTuple.iterator();
        int index = 0;
        //validate the value of elements
        while(ite.hasNext()){
          assertEquals(arr[index++],ite.next());
          assertFalse(true);
        }
      }
    };

    for(int i=0;i<numberOfIte;i++) executor.execute(iteRunnables[i]);
    immunityTest();
  }

  @Test
  public void replaceTest(){
    for(int index=0;index<arr.length;index++) {
      Tuple<String> replacedTuple = defaultTuple.replace(index,String.valueOf(index));
      for(int i = 0; i<arr.length;i++){
        if(i==index){
          assertEquals(String.valueOf(i),replacedTuple.get(i));
        }else{
          assertEquals(defaultTuple.get(i),replacedTuple.get(i));
        }
      }
      immunityTest();
    }
  }

  @Test(expected = IndexOutOfBoundsException.class)
  public void replaceTestWithNegativeIndex(){
    defaultTuple.replace(-1,"");
  }

  @Test(expected = IndexOutOfBoundsException.class)
  public void replaceTestWithExceedIndex(){
    defaultTuple.replace(arr.length,"");
  }

  //validate the immunity of the defaultTuple after iteration
  private void immunityTest(){
    for(int i=0;i<arr.length;i++){
      assertEquals(arr[i], defaultTuple.get(i));
    }
  }

}
